import GroupRoutes from './routes';

export {
  GroupRoutes,
};
