import UserRoutes from './routes';

export {
  UserRoutes,
};
