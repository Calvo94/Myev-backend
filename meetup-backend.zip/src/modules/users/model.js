import mongoose, { Schema } from 'mongoose';

const UserSchema = new Schema({
  username: String,
  suser: {
    type: Boolean,
    default: false,
  },
  group: {
    type: Schema.Types.ObjectId,
    ref: 'Group',
  },
  note: {
    type: Number,
    default: 0
  },
  nb: {
    type: Number,
    default: 0
  }
});

export default mongoose.model('User', UserSchema);
