import Meetup from './model';
import MeetupRoutes from './routes';

export {
  MeetupRoutes,
  Meetup,
};
