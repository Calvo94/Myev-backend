import Meetup from './model';

export const createMeetup = async (req, res) => {
  const { title, description, eventDate } = req.body;

  const date = new Date(eventDate);
  const newMeetup = new Meetup({ title, description, eventDate:date });

  try {
    return res.status(201).json({ meetup: await newMeetup.save() });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error with Meetup' });
  }
};

export const updateMeetup = async (req, res) => {
  const { title, description, eventDate } = req.body;
  const { meetupId } = req.params;
  const eventdate = new Date(eventDate);
  const updatemeetup = {
    title, description, eventDate:eventdate,
  };

  try {
    return res.status(201).json({ meetup: await Meetup.update({ _id:meetupId }, updatemeetup) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error updating Meetup' });
  }
};

export const imgMeetup = async (req, res) => {
  const { imgbase64 } = req.body;
  const { meetupId } = req.params;
  const updatemeetup = {
    imgbase64
  };

  try {
    return res.status(201).json({ meetup: await Meetup.update({ _id:meetupId }, updatemeetup) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error updating Meetup' });
  }
};

export const noteMeetup = async (req, res) => {
  const { note } = req.body;
  const { meetupId } = req.params;

try {
  return res.status(201).json({ meetup: await Meetup.update({ _id:meetupId }, {$inc: {nb:1 , note}  })});
} catch (e) {
  return res.status(e.status).json({ error: true, message: 'Error updating Meetup' });
}
};

export const make_Meetup_verified = async (req, res) => {
  const { meetupId } = req.params;

try {
  return res.status(201).json({ meetup: await Meetup.update({ _id:meetupId },{verified:true})});
} catch (e) {
  return res.status(e.status).json({ error: true, message: 'Error updating Meetup' });
}
};


export const deleteMeetup = async (req, res) => {

  const { meetupId } = req.params;

  try {
    return res.status(201).json({ meetup: await  Meetup.remove({_id:meetupId}) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error with Meetup' });
  }
};

export const getAllMeetups = async (req, res) => {
  try {

    return res.status(200).json({ meetups: await Meetup.find({}).sort({createdAt: -1}) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error with Meetup' });
  }
};

export const getUnverifiedMeetups = async (req, res) => {
  try {
    return res.status(200).json({ meetups: await Meetup.find({verified:false}).sort({createdAt: -1}) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error with Meetup' });
  }
};
export const getVerifiedMeetups = async (req, res) => {
  try {
    return res.status(200).json({ meetups: await Meetup.find({verified:true }).sort({createdAt: -1}) });
  } catch (e) {
    return res.status(e.status).json({ error: true, message: 'Error with Meetup' });
  }
};
