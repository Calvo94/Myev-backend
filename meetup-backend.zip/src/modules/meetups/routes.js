import { Router } from 'express';

import * as MeetupController from './controller';
import { requireJwtAuth } from '../../utils/requireJwtAuth';

const routes = new Router();

routes.post('/meetup', MeetupController.createMeetup);
routes.get('/meetups', MeetupController.getAllMeetups);
routes.get('/meetups/unverified', MeetupController.getUnverifiedMeetups);
routes.get('/meetups/verified', MeetupController.getVerifiedMeetups);
routes.post('/meetup/:meetupId', MeetupController.updateMeetup);
routes.post('/meetup/:meetupId/img', MeetupController.imgMeetup);
routes.post('/meetup/:meetupId/note', MeetupController.noteMeetup);
routes.post('/meetup/:meetupId/verif', MeetupController.make_Meetup_verified);
routes.delete('/meetup/:meetupId/delete', MeetupController.deleteMeetup);





export default routes;
