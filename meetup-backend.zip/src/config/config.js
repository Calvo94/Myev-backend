const devConfig = {
  DB_URL: 'mongodb://localhost/meetup-dev',
  JWT_SECRET: 'iuwbgu9bg98whwiv9wg98wghne908hgoin',
};

export default devConfig;
